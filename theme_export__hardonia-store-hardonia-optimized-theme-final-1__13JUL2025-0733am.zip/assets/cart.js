{
  "sections": {
    "hardonia_cart_main": {
      "type": "main-cart-items",
      "settings": {
        "show_vendor": false,
        "show_cart_note": true,
        "cart_notes_enable": true,
        "color_scheme": "background-1",
        "padding_top": 36,
        "padding_bottom": 12
      }
    },
    "hardonia_cart_footer": {
      "type": "main-cart-footer",
      "blocks": {
        "subtotal": {
          "type": "subtotal",
          "settings": {}
        },
        "shipping_estimator": {
          "type": "shipping_estimator",
          "settings": {}
        },
        "buttons": {
          "type": "buttons",
          "settings": {}
        }
      },
      "block_order": [
        "subtotal",
        "shipping_estimator", 
        "buttons"
      ],
      "settings": {
        "color_scheme": "background-1",
        "padding_top": 12,
        "padding_bottom": 36
      }
    },
    "hardonia_cart_trust": {
      "type": "multicolumn",
      "blocks": {
        "trust_secure": {
          "type": "column",
          "settings": {
            "title": "Secure Checkout",
            "text": "<p>Your payment information is processed securely with SSL encryption</p>",
            "link_label": "",
            "link": ""
          }
        },
        "trust_shipping": {
          "type": "column",
          "settings": {
            "title": "Free Shipping",
            "text": "<p>Free delivery on orders over £35 with fast, reliable shipping</p>",
            "link_label": "",
            "link": ""
          }
        },
        "trust_returns": {
          "type": "column",
          "settings": {
            "title": "Easy Returns",
            "text": "<p>30-day hassle-free returns and exchanges for your peace of mind</p>",
            "link_label": "",
            "link": ""
          }
        },
        "trust_support": {
          "type": "column",
          "settings": {
            "title": "Customer Support",
            "text": "<p>Our dedicated team is here to help with any questions or concerns</p>",
            "link_label": "",
            "link": ""
          }
        }
      },
      "block_order": [
        "trust_secure",
        "trust_shipping",
        "trust_returns",
        "trust_support"
      ],
      "settings": {
        "title": "Shopping with Confidence",
        "heading_size": "h2",
        "image_width": "full",
        "image_ratio": "adapt",
        "columns_desktop": 4,
        "column_alignment": "center",
        "background_style": "primary",
        "button_label": "",
        "button_link": "",
        "color_scheme": "background-2",
        "columns_mobile": "2",
        "swipe_on_mobile": false,
        "padding_top": 36,
        "padding_bottom": 36
      }
    },
    "hardonia_cart_recommendations": {
      "type": "hardonia-product-showcase",
      "settings": {
        "title": "Complete Your Purchase",
        "description": "<p>Customers who bought these items also loved these products</p>",
        "collection": "frontpage",
        "products_to_show": 4,
        "show_description": false,
        "show_add_to_cart": true,
        "show_view_all": false,
        "view_all_text": "",
        "background_color": "#ffffff",
        "color_scheme": "background-1",
        "padding_top": 36,
        "padding_bottom": 36
      }
    },
    "hardonia_cart_empty_state": {
      "type": "rich-text",
      "blocks": {
        "empty_heading": {
          "type": "heading",
          "settings": {
            "heading": "<p>Your Cart is Empty</p>",
            "heading_size": "h2"
          }
        },
        "empty_text": {
          "type": "text",
          "settings": {
            "text": "<p>Discover our amazing collection of products for home, outdoor, lifestyle, and more. Start building your perfect selection today!</p>"
          }
        },
        "empty_button": {
          "type": "button",
          "settings": {
            "button_label": "Start Shopping",
            "button_link": "shopify://collections/all",
            "button_style_secondary": false,
            "button_label_2": "Browse Categories",
            "button_link_2": "shopify://collections",
            "button_style_secondary_2": true
          }
        }
      },
      "block_order": [
        "empty_heading",
        "empty_text",
        "empty_button"
      ],
      "settings": {
        "desktop_content_position": "center",
        "content_alignment": "center",
        "color_scheme": "background-1",
        "full_width": true,
        "padding_top": 40,
        "padding_bottom": 52
      },
      "disabled": true
    },
    "hardonia_recently_viewed_cart": {
      "type": "recently-viewed-products", 
      "settings": {
        "title": "Recently Viewed",
        "products_to_show": 4,
        "image_ratio": "square",
        "show_secondary_image": true,
        "show_vendor": false,
        "show_rating": true,
        "color_scheme": "background-2",
        "padding_top": 36,
        "padding_bottom": 36
      }
    }
  },
  "order": [
    "hardonia_cart_main",
    "hardonia_cart_footer",
    "hardonia_cart_trust",
    "hardonia_cart_recommendations",
    "hardonia_recently_viewed_cart"
  ]
}